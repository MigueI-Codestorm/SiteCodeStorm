import React from 'react';
import { motion } from 'framer-motion';
import { Bot, Cpu, Globe, Zap } from 'lucide-react';

const News: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark pt-24">
      <div className="container-custom py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-orbitron font-bold mb-6">
            Novidades da <span className="gradient-text">CodeStorm</span>
          </h1>
          <p className="text-xl text-gray-light max-w-3xl mx-auto">
            Acompanhe as últimas atualizações, lançamentos e novidades sobre nossos produtos e serviços.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-gray-dark rounded-lg overflow-hidden group hover:shadow-lg hover:shadow-blue-electric/20 transition-all"
          >
            <div className="h-48 bg-gradient-to-br from-blue-electric/20 to-purple-neon/20 flex items-center justify-center">
              <Bot className="w-16 h-16 text-blue-electric group-hover:scale-110 transition-transform" />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-orbitron mb-4">
                Lançamento: SophIA - Nossa IA Assistente
              </h2>
              <p className="text-gray-light mb-4">
                Conheça nossa nova assistente virtual inteligente, capaz de atender seus clientes 24/7 com eficiência e personalidade.
              </p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-light">15 de Março, 2025</span>
                <button className="text-blue-electric hover:text-blue-electric/80 transition-colors">
                  Ler mais
                </button>
              </div>
            </div>
          </motion.article>

          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-gray-dark rounded-lg overflow-hidden group hover:shadow-lg hover:shadow-blue-electric/20 transition-all"
          >
            <div className="h-48 bg-gradient-to-br from-purple-neon/20 to-blue-electric/20 flex items-center justify-center">
              <Cpu className="w-16 h-16 text-purple-neon group-hover:scale-110 transition-transform" />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-orbitron mb-4">
                Nova Plataforma de Automação
              </h2>
              <p className="text-gray-light mb-4">
                Automatize processos complexos com nossa nova plataforma integrada de IA e machine learning.
              </p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-light">10 de Março, 2025</span>
                <button className="text-blue-electric hover:text-blue-electric/80 transition-colors">
                  Ler mais
                </button>
              </div>
            </div>
          </motion.article>

          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-gray-dark rounded-lg overflow-hidden group hover:shadow-lg hover:shadow-blue-electric/20 transition-all"
          >
            <div className="h-48 bg-gradient-to-br from-blue-electric/20 to-purple-neon/20 flex items-center justify-center">
              <Globe className="w-16 h-16 text-blue-electric group-hover:scale-110 transition-transform" />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-orbitron mb-4">
                Novo Framework Web
              </h2>
              <p className="text-gray-light mb-4">
                Desenvolvemos um framework próprio para criação de sites modernos e otimizados para SEO.
              </p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-light">5 de Março, 2025</span>
                <button className="text-blue-electric hover:text-blue-electric/80 transition-colors">
                  Ler mais
                </button>
              </div>
            </div>
          </motion.article>
        </div>

        <div className="mt-16 text-center">
          <button className="btn btn-outline">
            Carregar mais notícias
          </button>
        </div>
      </div>
    </div>
  );
};

export default News