import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Download, ArrowRight, CheckCircle, XCircle } from 'lucide-react';

const WhyAI: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark">
      <div className="container-custom py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-orbitron font-bold mb-6 text-center">
            Funcionário ou <span className="gradient-text">Agente de IA</span>?
          </h1>
          <p className="text-xl md:text-2xl text-center text-gray-light mb-12">
            A decisão que pode acelerar (ou frear) o crescimento da sua empresa.
          </p>

          <div className="bg-darker rounded-lg p-8 mb-12">
            <p className="text-xl mb-6">
              Você sabia que mais de 75% das empresas que adotaram automação com IA viram aumento imediato na produtividade e redução de custos?
            </p>
            <p className="text-lg text-gray-light mb-6">
              Enquanto muitos negócios ainda sustentam estruturas caras e limitadas, <strong>a revolução dos Agentes de Inteligência Artificial já começou.</strong>
            </p>
            <p className="text-lg text-gray-light">
              Descubra agora, com clareza visual, <strong>qual caminho realmente impulsiona resultados.</strong>
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-gray-dark rounded-lg p-6 border border-error/30">
              <h3 className="text-2xl font-orbitron mb-6 flex items-center gap-2 text-error">
                <XCircle className="w-8 h-8" />
                Funcionário Tradicional
              </h3>
              <ul className="space-y-4">
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Salário fixo mensal
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Impostos e encargos trabalhistas
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Férias remuneradas e benefícios
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Treinamento constante
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Alta rotatividade
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Horário limitado e folgas
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Fadiga e baixa performance
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <XCircle className="w-5 h-5 text-error" />
                  Burocracia crescente
                </li>
              </ul>
            </div>

            <div className="bg-gray-dark rounded-lg p-6 border border-success/30">
              <h3 className="text-2xl font-orbitron mb-6 flex items-center gap-2 text-success">
                <CheckCircle className="w-8 h-8" />
                Agente de IA (SophIA)
              </h3>
              <ul className="space-y-4">
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Disponível 24h/7 dias
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Zero encargos trabalhistas
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Atendimento instantâneo
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Performance constante
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Sem rotatividade
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Aprendizado contínuo
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Redução de custos
                </li>
                <li className="flex items-center gap-2 text-gray-light">
                  <CheckCircle className="w-5 h-5 text-success" />
                  Aumento na conversão
                </li>
              </ul>
            </div>
          </div>

          <div className="text-center mb-16">
            <h2 className="text-3xl font-orbitron mb-6">
              Você prefere sustentar uma estrutura pesada e ineficiente…<br />
              ou dar um salto real com inteligência automatizada?
            </h2>
            <p className="text-xl text-gray-light">
              A CodeStorm entrega soluções que funcionam enquanto você dorme — literalmente.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Autoridade</h3>
              <p className="text-gray-light">
                A CodeStorm é referência nacional em automação inteligente, atendendo empresas de diversos setores com soluções reais baseadas em IA de ponta.
              </p>
            </div>

            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Prova Social</h3>
              <p className="text-gray-light">
                Empresas que integraram nossos agentes inteligentes reduziram seus custos operacionais em até 68%, aumentando o atendimento e a conversão.
              </p>
            </div>

            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Escassez</h3>
              <p className="text-gray-light">
                Estamos oferecendo uma consultoria gratuita para os primeiros 10 negócios que desejam automatizar seus processos agora.
              </p>
            </div>

            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Compromisso</h3>
              <p className="text-gray-light">
                Se você já está buscando inovação, tecnologia e produtividade, então escolher um Agente IA é o próximo passo natural.
              </p>
            </div>

            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Contraste</h3>
              <p className="text-gray-light">
                O modelo tradicional é lento, caro e limitado. O novo modelo é rápido, acessível e imparável.
              </p>
            </div>

            <div className="bg-gray-dark rounded-lg p-6">
              <h3 className="text-xl font-orbitron mb-4">Reciprocidade</h3>
              <p className="text-gray-light">
                Como forma de agradecer por visitar essa página, oferecemos um eBook gratuito com 7 dicas de automação.
              </p>
            </div>
          </div>

          <div className="text-center mb-16">
            <button className="btn btn-outline mb-8">
              <Download className="w-5 h-5 mr-2" />
              Baixar eBook gratuitamente
            </button>
          </div>

          <div className="bg-gradient-to-r from-blue-electric/20 via-purple-neon/20 to-blue-electric/20 rounded-lg p-8 text-center">
            <h2 className="text-3xl font-orbitron mb-6">
              Seu concorrente está testando IA neste exato momento.<br />
              <span className="gradient-text">A diferença é que você ainda pode sair na frente.</span>
            </h2>

            <Link
              to="/#contact"
              className="btn btn-primary inline-flex items-center group"
            >
              Fale com um Especialista
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default WhyAI