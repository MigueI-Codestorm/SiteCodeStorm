import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Benefits from './components/Benefits';
import Testimonials from './components/Testimonials';
import CallToAction from './components/CallToAction';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ChatWidget from './components/ChatWidget';
import WhyAI from './pages/WhyAI';
import News from './pages/News';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-dark">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <main>
              <Hero />
              <About />
              <Services />
              <Benefits />
              <Testimonials />
              <CallToAction />
              <Contact />
            </main>
          } />
          <Route path="/why-ai" element={<WhyAI />} />
          <Route path="/news" element={<News />} />
        </Routes>
        <Footer />
        <ChatWidget />
      </div>
    </Router>
  );
}

export default App;