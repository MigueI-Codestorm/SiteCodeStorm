import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const CallToAction: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background with gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-neon/20 via-darker to-blue-electric/20 animated-bg"></div>
      
      {/* Grid overlay */}
      <div className="absolute inset-0 bg-cyber-grid bg-cyber-grid-size opacity-10"></div>
      
      {/* Content */}
      <div className="container-custom relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-orbitron font-bold mb-6 text-white">
            Comece hoje mesmo a <span className="gradient-text">evoluir</span> seu negócio.
          </h2>
          <p className="text-xl mb-10 text-gray-light">
            Transforme sua empresa com tecnologia de ponta e soluções inteligentes.
          </p>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <a 
              href="#contact" 
              className="btn btn-primary text-lg px-8 py-4 shadow-lg shadow-blue-electric/30 animate-pulse-slow"
            >
              Fale com um especialista
            </a>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-blue-electric/10 rounded-full blur-xl"></div>
      <div className="absolute -top-16 -right-16 w-64 h-64 bg-purple-neon/10 rounded-full blur-xl"></div>
    </section>
  );
};

export default CallToAction;