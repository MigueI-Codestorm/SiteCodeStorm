import React from 'react';
import { Zap, Mail, MapPin, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-darker pt-16 border-t border-gray-dark">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <Zap size={28} className="text-blue-electric" />
              <span className="font-orbitron font-bold text-xl text-white">
                Code<span className="text-blue-electric">Storm</span>
              </span>
            </div>
            <p className="text-gray-light mb-6">
              Transformamos ideias em sistemas inteligentes, sites modernos e soluções com IA.
            </p>
            <div className="flex items-center text-gray-light">
              <Mail size={16} className="mr-2" />
              <a href="mailto:contato@codestrm.com.br" className="hover:text-blue-electric transition-colors">
                contato@codestrm.com.br
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Links Rápidos</h3>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-gray-light hover:text-blue-electric transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="text-gray-light hover:text-blue-electric transition-colors">
                  Sobre
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-light hover:text-blue-electric transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#benefits" className="text-gray-light hover:text-blue-electric transition-colors">
                  Benefícios
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-light hover:text-blue-electric transition-colors">
                  Contato
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Serviços</h3>
            <ul className="space-y-3">
              <li>
                <a href="#services" className="text-gray-light hover:text-blue-electric transition-colors">
                  Agentes de IA
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-light hover:text-blue-electric transition-colors">
                  Automação de Processos
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-light hover:text-blue-electric transition-colors">
                  Sistemas Inteligentes
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-light hover:text-blue-electric transition-colors">
                  Websites Modernos
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Contato</h3>
            <ul className="space-y-4">
              <li className="flex">
                <MapPin size={18} className="text-blue-electric mt-1 mr-3 flex-shrink-0" />
                <span className="text-gray-light">
                  Av. Paulista, 1578<br />
                  São Paulo, SP<br />
                  Brasil
                </span>
              </li>
              <li className="flex">
                <Phone size={18} className="text-blue-electric mt-1 mr-3 flex-shrink-0" />
                <span className="text-gray-light">
                  +55 11 3456-7890
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="py-6 border-t border-gray-dark">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-light text-sm">
              © {currentYear} CodeStorm. Todos os direitos reservados.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a href="#" className="text-gray-light hover:text-white text-sm">
                Política de Privacidade
              </a>
              <a href="#" className="text-gray-light hover:text-white text-sm">
                Termos de Uso
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;