import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Send, CheckCircle, AlertCircle, Linkedin, Github, Instagram, MessageSquare } from 'lucide-react';

interface FormInputs {
  name: string;
  company: string;
  email: string;
  message: string;
}

const Contact: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  
  const { 
    register, 
    handleSubmit, 
    reset,
    formState: { errors } 
  } = useForm<FormInputs>();
  
  const onSubmit: SubmitHandler<FormInputs> = async (data) => {
    setFormStatus('submitting');
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In a real application, you would send the data to a server here
      console.log('Form data submitted:', data);
      
      setFormStatus('success');
      reset();
      
      // Reset form status after 5 seconds
      setTimeout(() => {
        setFormStatus('idle');
      }, 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
      setFormStatus('error');
      
      // Reset form status after 5 seconds
      setTimeout(() => {
        setFormStatus('idle');
      }, 5000);
    }
  };

  const socialLinks = [
    { 
      icon: <Linkedin size={20} />, 
      href: "https://linkedin.com", 
      label: "LinkedIn" 
    },
    { 
      icon: <Github size={20} />, 
      href: "https://github.com", 
      label: "GitHub" 
    },
    { 
      icon: <Instagram size={20} />, 
      href: "https://instagram.com", 
      label: "Instagram" 
    },
    { 
      icon: <MessageSquare size={20} />, 
      href: "https://wa.me/123456789", 
      label: "WhatsApp" 
    },
  ];

  return (
    <section id="contact" className="section bg-gradient-to-b from-dark to-darker">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">Entre em <span className="gradient-text">contato</span></h2>
          <p className="section-subtitle max-w-3xl mx-auto">
            Estamos prontos para transformar sua empresa com tecnologia de ponta
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-orbitron mb-6">Fale Conosco</h3>
            <p className="text-gray-light mb-8">
              Preencha o formulário ou entre em contato diretamente pelo e-mail ou redes sociais.
            </p>
            
            <div className="mb-8">
              <h4 className="text-lg font-medium mb-3">E-mail</h4>
              <a 
                href="mailto:contato@codestrm.com.br" 
                className="text-blue-electric hover:text-blue-electric/80 transition-colors"
              >
                contato@codestrm.com.br
              </a>
            </div>
            
            <div>
              <h4 className="text-lg font-medium mb-3">Redes Sociais</h4>
              <div className="flex space-x-4">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-gray-dark rounded-full text-gray-light hover:text-blue-electric hover:bg-gray-dark/80 transition-all"
                    aria-label={link.label}
                  >
                    {link.icon}
                  </a>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-light mb-2">
                  Nome
                </label>
                <input
                  id="name"
                  type="text"
                  className={`input-field ${errors.name ? 'border-error' : ''}`}
                  placeholder="Seu nome completo"
                  {...register("name", { required: "Nome é obrigatório" })}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-error">{errors.name.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-light mb-2">
                  Empresa
                </label>
                <input
                  id="company"
                  type="text"
                  className="input-field"
                  placeholder="Nome da sua empresa"
                  {...register("company")}
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-light mb-2">
                  E-mail
                </label>
                <input
                  id="email"
                  type="email"
                  className={`input-field ${errors.email ? 'border-error' : ''}`}
                  placeholder="seu@email.com"
                  {...register("email", { 
                    required: "E-mail é obrigatório",
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: "E-mail inválido"
                    }
                  })}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-error">{errors.email.message}</p>
                )}
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-light mb-2">
                  Mensagem
                </label>
                <textarea
                  id="message"
                  rows={5}
                  className={`input-field resize-none ${errors.message ? 'border-error' : ''}`}
                  placeholder="Descreva seu projeto ou necessidade..."
                  {...register("message", { required: "Mensagem é obrigatória" })}
                ></textarea>
                {errors.message && (
                  <p className="mt-1 text-sm text-error">{errors.message.message}</p>
                )}
              </div>
              
              <button
                type="submit"
                disabled={formStatus === 'submitting'}
                className={`btn btn-primary w-full flex items-center justify-center ${
                  formStatus === 'submitting' ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {formStatus === 'idle' && (
                  <>
                    <span>Enviar mensagem</span>
                    <Send size={18} className="ml-2" />
                  </>
                )}
                
                {formStatus === 'submitting' && (
                  <>
                    <span>Enviando...</span>
                    <div className="ml-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  </>
                )}
                
                {formStatus === 'success' && (
                  <>
                    <span>Mensagem enviada!</span>
                    <CheckCircle size={18} className="ml-2 text-success" />
                  </>
                )}
                
                {formStatus === 'error' && (
                  <>
                    <span>Erro ao enviar. Tente novamente.</span>
                    <AlertCircle size={18} className="ml-2 text-error" />
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;