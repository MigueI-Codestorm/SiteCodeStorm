import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import ParticlesBackground from './ParticlesBackground';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative h-screen flex items-center overflow-hidden">
      <ParticlesBackground />
      
      <div className="container-custom relative z-10">
        <div className="max-w-3xl">
          <motion.h1 
            className="text-4xl md:text-5xl lg:text-6xl font-orbitron font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Funcionário ou <span className="gradient-text">Agente de IA</span>?
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl mb-8 text-gray-light"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            A decisão que pode transformar seu negócio.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Link 
              to="/why-ai"
              className="btn btn-primary mr-4 shadow-lg shadow-blue-electric/30 hover:shadow-blue-electric/50 hover:scale-105 transition-all duration-300"
            >
              Descubra as Vantagens da IA
            </Link>
          </motion.div>
        </div>
      </div>
      
      {/* Abstract digital graphic element */}
      <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-1/2 h-1/2 opacity-60 hidden lg:block">
        <motion.div 
          className="w-full h-full"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5, delay: 0.6 }}
        >
          <div className="relative w-full h-full">
            <div className="absolute w-64 h-64 rounded-full border-4 border-blue-electric/30 animate-pulse-slow"></div>
            <div className="absolute w-96 h-96 rounded-full border-2 border-purple-neon/20 left-24 top-24"></div>
            <div className="absolute w-32 h-32 bg-gradient-to-br from-blue-electric/40 to-purple-neon/40 rounded-xl blur-xl left-48 top-32 animate-float"></div>
          </div>
        </motion.div>
      </div>
      
      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-dark to-transparent"></div>
    </section>
  );
};

export default Hero