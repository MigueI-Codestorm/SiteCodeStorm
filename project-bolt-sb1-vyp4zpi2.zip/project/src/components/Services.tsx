import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Bot, Cog, Cpu, Globe } from 'lucide-react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description, delay }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay }}
      className="card neon-border group hover:translate-y-[-8px]"
    >
      <div className="p-3 bg-blue-electric/10 rounded-full w-fit mb-6 group-hover:bg-blue-electric/20 transition-colors">
        {icon}
      </div>
      <h3 className="text-xl font-orbitron mb-3 text-white group-hover:text-blue-electric transition-colors">
        {title}
      </h3>
      <p className="text-gray-light">
        {description}
      </p>
    </motion.div>
  );
};

const Services: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const services = [
    {
      icon: <Bot className="w-8 h-8 text-blue-electric" />,
      title: "Agentes de IA personalizados",
      description: "Atendem 24h por dia, sem falhas, sem salário.",
      delay: 0.2,
    },
    {
      icon: <Cog className="w-8 h-8 text-blue-electric" />,
      title: "Automação de processos",
      description: "Reduza erros, ganhe tempo e corte custos.",
      delay: 0.3,
    },
    {
      icon: <Cpu className="w-8 h-8 text-blue-electric" />,
      title: "Sistemas inteligentes",
      description: "Da ideia ao código, com foco em performance e inteligência.",
      delay: 0.4,
    },
    {
      icon: <Globe className="w-8 h-8 text-blue-electric" />,
      title: "Sites modernos",
      description: "Design marcante, performance otimizada e acessibilidade real.",
      delay: 0.5,
    }
  ];

  return (
    <section id="services" className="section bg-dark relative">
      {/* Background grid */}
      <div className="absolute inset-0 bg-cyber-grid bg-cyber-grid-size opacity-10"></div>
      
      <div className="container-custom relative">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">O que <span className="gradient-text">oferecemos</span></h2>
          <p className="section-subtitle max-w-3xl mx-auto">
            Soluções inteligentes para transformar seu negócio
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              delay={service.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;