import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { TrendingUp, Clock, Users, BarChart3 } from 'lucide-react';

interface BenefitItemProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
  delay: number;
}

const BenefitItem: React.FC<BenefitItemProps> = ({ icon, title, value, description, delay }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, delay }}
      className="relative bg-gray-dark rounded-lg p-6 flex flex-col items-center text-center hover:bg-gray-dark/80 transition-colors border border-gray-dark hover:border-blue-electric/30"
    >
      <div className="p-3 bg-blue-electric/10 rounded-full mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <div className="text-3xl font-orbitron font-bold text-blue-electric mb-2">{value}</div>
      <p className="text-gray-light text-sm">{description}</p>
    </motion.div>
  );
};

const Benefits: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const benefits = [
    {
      icon: <TrendingUp className="w-6 h-6 text-blue-electric" />,
      title: "Redução de custos",
      value: "-30%",
      description: "Custos operacionais reduzidos significativamente",
      delay: 0.2,
    },
    {
      icon: <Clock className="w-6 h-6 text-blue-electric" />,
      title: "Atendimento contínuo",
      value: "24/7",
      description: "Suporte ao cliente sem interrupções",
      delay: 0.3,
    },
    {
      icon: <Users className="w-6 h-6 text-blue-electric" />,
      title: "Aumento na produtividade",
      value: "+150%",
      description: "Processos otimizados geram mais resultados",
      delay: 0.4,
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-blue-electric" />,
      title: "Taxa de conversão",
      value: "+45%",
      description: "Mais visitantes se tornam clientes pagantes",
      delay: 0.5,
    },
  ];

  return (
    <section id="benefits" className="section bg-gradient-to-b from-darker to-dark">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">Benefícios para sua <span className="gradient-text">empresa</span></h2>
          <p className="section-subtitle max-w-3xl mx-auto">
            Resultados mensuráveis que impactam positivamente seu negócio
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <BenefitItem
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              value={benefit.value}
              description={benefit.description}
              delay={benefit.delay}
            />
          ))}
        </div>

        {/* Bottom graphic */}
        <div className="mt-16 flex justify-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="relative h-32 w-full max-w-3xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-electric/20 via-purple-neon/20 to-blue-electric/20 rounded-lg"></div>
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-electric via-purple-neon to-blue-electric"></div>
            
            {/* Graph bars */}
            <div className="absolute bottom-4 left-0 right-0 flex justify-between px-6">
              <div className="flex flex-col items-center">
                <div className="h-8 w-6 bg-blue-electric/40 rounded-t-sm"></div>
                <span className="text-xs mt-1 text-gray-light">Q1</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-12 w-6 bg-blue-electric/60 rounded-t-sm"></div>
                <span className="text-xs mt-1 text-gray-light">Q2</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-16 w-6 bg-blue-electric/80 rounded-t-sm"></div>
                <span className="text-xs mt-1 text-gray-light">Q3</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="h-20 w-6 bg-blue-electric rounded-t-sm"></div>
                <span className="text-xs mt-1 text-gray-light">Q4</span>
              </div>
            </div>
            
            <div className="absolute top-2 left-4 text-xs text-gray-light">Crescimento com IA</div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;