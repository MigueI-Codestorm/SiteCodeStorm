import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Quote } from 'lucide-react';

interface TestimonialProps {
  quote: string;
  author: string;
  position: string;
  image: string;
}

const Testimonial: React.FC<TestimonialProps> = ({ quote, author, position, image }) => {
  return (
    <div className="px-4 py-8">
      <div className="bg-gray-dark rounded-lg p-6 md:p-8 relative border border-gray-dark hover:border-blue-electric/30 transition-all duration-300">
        <div className="absolute -top-4 -left-2">
          <Quote className="w-8 h-8 text-blue-electric opacity-50" />
        </div>
        <p className="text-gray-light mb-6 relative z-10">"{quote}"</p>
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
            <img src={image} alt={author} className="w-full h-full object-cover" />
          </div>
          <div>
            <h4 className="font-medium text-white">{author}</h4>
            <p className="text-sm text-gray-light">{position}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const Testimonials: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      }
    ],
    customPaging: (i: number) => (
      <div className="w-3 h-3 mx-1 rounded-full bg-gray-light opacity-50 hover:opacity-100 transition-opacity"></div>
    ),
  };

  const testimonials = [
    {
      quote: "Nunca imaginei que um agente de IA pudesse substituir nossa central de atendimento com tanta eficiência.",
      author: "Ana Silva",
      position: "Diretora de Operações",
      image: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "A CodeStorm levou nossa automação para outro nível. Reduzimos nossos custos operacionais em 40%.",
      author: "Carlos Mendes",
      position: "CTO, TechSolutions",
      image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "O site que desenvolveram para nós não só é visualmente impressionante, mas também converteu 35% mais visitantes.",
      author: "Fernanda Costa",
      position: "Gerente de Marketing",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "Os sistemas inteligentes implementados transformaram completamente nosso fluxo de trabalho e produtividade.",
      author: "Ricardo Oliveira",
      position: "CEO, Innovate Inc",
      image: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      quote: "A solução de IA personalizada que a CodeStorm desenvolveu superou todas as nossas expectativas.",
      author: "Marina Santos",
      position: "Diretora de Inovação",
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150"
    }
  ];

  return (
    <section className="section bg-dark relative">
      {/* Background grid */}
      <div className="absolute inset-0 bg-cyber-grid bg-cyber-grid-size opacity-10"></div>
      
      <div className="container-custom relative">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">O que nossos <span className="gradient-text">clientes</span> dizem</h2>
          <p className="section-subtitle max-w-3xl mx-auto">
            Histórias reais de sucesso com nossas soluções
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <Slider {...settings}>
            {testimonials.map((testimonial, index) => (
              <Testimonial
                key={index}
                quote={testimonial.quote}
                author={testimonial.author}
                position={testimonial.position}
                image={testimonial.image}
              />
            ))}
          </Slider>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;