import React, { useState, useEffect } from 'react';
import { Menu, X, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);
  
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Sobre', href: '/#about' },
    { name: 'Serviços', href: '/#services' },
    { name: 'Benefícios', href: '/#benefits' },
    { name: 'Novidades', href: '/news' },
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-darker/90 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container-custom py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2">
          <Zap size={32} className="text-blue-electric" />
          <span className="font-orbitron font-bold text-xl text-white">
            Code<span className="text-blue-electric">Storm</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              className="text-gray-light hover:text-white transition-colors"
            >
              {link.name}
            </Link>
          ))}
          <a 
            href="#contact" 
            className="btn btn-primary"
          >
            Fale Conosco
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white" onClick={toggleMenu}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <nav className="md:hidden bg-darker/95 backdrop-blur-md absolute w-full py-4">
          <div className="container-custom flex flex-col space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className="text-gray-light hover:text-white py-2 transition-colors"
                onClick={toggleMenu}
              >
                {link.name}
              </Link>
            ))}
            <a 
              href="#contact" 
              className="btn btn-primary w-full text-center"
              onClick={toggleMenu}
            >
              Fale Conosco
            </a>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Navbar