import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { BrainCircuit } from 'lucide-react';

const About: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const variants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="about" className="section bg-gradient-to-b from-dark to-darker">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          transition={{ duration: 0.8 }}
          variants={variants}
          className="text-center mb-12"
        >
          <h2 className="section-title">Sobre a <span className="gradient-text">CodeStorm</span></h2>
          <p className="section-subtitle max-w-3xl mx-auto">
            Transformamos ideias em sistemas inteligentes, sites modernos e soluções com IA.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            transition={{ duration: 0.8, delay: 0.2 }}
            variants={variants}
          >
            <p className="text-lg mb-6 text-gray-light">
              Com inovação, tecnologia e automação, criamos experiências digitais funcionais, 
              ousadas e acessíveis para empresas e desenvolvedores de todos os tamanhos.
            </p>
            <p className="text-lg text-gray-light">
              Nossa missão é potencializar negócios através da tecnologia de ponta, 
              tornando acessível o que antes era exclusivo apenas para grandes corporações.
            </p>
            <div className="mt-8">
              <a href="#services" className="btn btn-outline">
                Conheça nossos serviços
              </a>
            </div>
          </motion.div>

          <motion.div
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            transition={{ duration: 0.8, delay: 0.4 }}
            variants={variants}
            className="relative"
          >
            <div className="relative bg-gray-dark rounded-lg p-6 border border-gray-dark overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-blue-electric/10 rounded-bl-full"></div>
              
              <div className="flex items-center mb-6">
                <div className="p-3 bg-blue-electric/10 rounded-full mr-4">
                  <BrainCircuit className="w-8 h-8 text-blue-electric" />
                </div>
                <h3 className="text-xl font-orbitron">Antes e Depois da IA</h3>
              </div>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-darker rounded-lg">
                  <div>
                    <h4 className="text-sm text-gray-light">Antes</h4>
                    <p className="font-medium">Processos manuais e lentos</p>
                  </div>
                  <span className="text-error">-35% produtividade</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-darker rounded-lg">
                  <div>
                    <h4 className="text-sm text-gray-light">Depois</h4>
                    <p className="font-medium">Automação inteligente</p>
                  </div>
                  <span className="text-success">+150% eficiência</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-darker rounded-lg">
                  <div>
                    <h4 className="text-sm text-gray-light">Antes</h4>
                    <p className="font-medium">Atendimento limitado</p>
                  </div>
                  <span className="text-error">8h por dia</span>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-darker rounded-lg">
                  <div>
                    <h4 className="text-sm text-gray-light">Depois</h4>
                    <p className="font-medium">IA respondendo dúvidas</p>
                  </div>
                  <span className="text-success">24h por dia</span>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-purple-neon/10 rounded-tr-full -z-10"></div>
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-blue-electric/20 rounded-full -z-10 animate-pulse-slow"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;