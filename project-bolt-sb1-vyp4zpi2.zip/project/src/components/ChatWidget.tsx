import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, X, Bot } from 'lucide-react';

const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const toggleChat = () => setIsOpen(!isOpen);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Logic for handling chat messages will be implemented later
    setMessage('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-[350px] bg-darker rounded-lg shadow-xl border border-gray-dark overflow-hidden"
          >
            <div className="p-4 bg-gray-dark border-b border-gray-dark flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Bot className="w-6 h-6 text-blue-electric" />
                <span className="font-medium">SophIA</span>
              </div>
              <button
                onClick={toggleChat}
                className="text-gray-light hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="h-[400px] p-4 overflow-y-auto">
              <div className="flex items-start gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-blue-electric/10 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-blue-electric" />
                </div>
                <div className="bg-gray-dark rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm">
                    Olá! Sou a SophIA, a assistente virtual da CodeStorm. Como posso ajudar você hoje?
                  </p>
                </div>
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="p-4 border-t border-gray-dark">
              <div className="relative">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Pergunte qualquer coisa sobre a CodeStorm..."
                  className="w-full bg-gray-dark rounded-full pl-4 pr-12 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-electric"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full bg-blue-electric text-white hover:bg-blue-electric/80 transition-colors"
                >
                  <Send size={16} />
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={toggleChat}
        className="w-14 h-14 rounded-full bg-blue-electric text-white shadow-lg hover:shadow-blue-electric/50 transition-shadow flex items-center justify-center relative group"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Bot size={24} className="group-hover:scale-110 transition-transform" />
        <span className="absolute top-0 right-0 w-3 h-3 bg-success rounded-full border-2 border-darker"></span>
      </motion.button>
    </div>
  );
};

export default ChatWidget;