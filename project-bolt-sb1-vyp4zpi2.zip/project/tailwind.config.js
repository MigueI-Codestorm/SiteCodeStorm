/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        dark: '#121212',
        darker: '#0A0A0A',
        'blue-electric': '#3D5AFE',
        'purple-neon': '#B026FF',
        'gray-dark': '#1E1E1E',
        'gray-light': '#A0A0A0',
        success: '#00C853',
        warning: '#FFD600',
        error: '#FF3D00',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        orbitron: ['Orbitron', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 3s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(61, 90, 254, 0.5)' },
          '100%': { boxShadow: '0 0 20px rgba(176, 38, 255, 0.8)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'cyber-grid': 'linear-gradient(rgba(61, 90, 254, 0.15) 1px, transparent 1px), linear-gradient(to right, rgba(61, 90, 254, 0.15) 1px, transparent 1px)',
      },
      backgroundSize: {
        'cyber-grid-size': '30px 30px',
      },
    },
  },
  plugins: [],
};